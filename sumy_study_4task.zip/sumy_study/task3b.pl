#!/usr/bin/perl

use strict;
use warnings;

my $dict      = '/etc/dictionaries-common/words';
my %full_dict ;
my $count     = 1;

open ( my $fh, "<", $dict ) or die "Cannot open a file $dict: $!\n";
print "Enter the word for search:\nNote: the search is case insensitive\n\n";

while (<$fh>) {
    chomp ( my $word = lc );
    $full_dict{$word} = $count++;
}

while (<>) {
    chomp;
    my $word = lc;
    $full_dict{$word} ? ( print "Found $_ at $full_dict{$word}\n" ) : ( print "No matches found!\n" );
    print "\nTry again:\n";
} 